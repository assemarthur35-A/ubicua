/* Testes das regras de negócio (demanda e agenda) sem navegador.
   Os scripts do site são globais; aqui são carregados num contexto isolado do Node.
   Rode com: npm test */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadSite() {
  const ctx = vm.createContext({ console, Date, Math, JSON, Object, Array, String, Number });
  ['utils', 'data', 'state', 'schedule', 'demand'].forEach((f) => {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'js', f + '.js'), 'utf8'), ctx, { filename: f + '.js' });
  });
  return ctx;
}
const run = (ctx, code) => vm.runInContext(code, ctx);

test('demanda: pontuação = 50% ocupação + 50% pressão da fila', () => {
  const c = loadSite();
  run(c, "state.hs.hmv={fila:30,plant:6,leitos:65,total:130}");
  // ocupação 50%, pressão 30/(6*5)=100% -> (50+100)/2 = 75 -> nível alta
  const D = run(c, 'demand("hmv")');
  assert.equal(D.score, 75);
  assert.equal(D.lvl.id, 'alta');
  assert.equal(D.wait, 60);
});

test('demanda: pressão da fila é limitada a 100%', () => {
  const c = loadSite();
  run(c, "state.hs.upa={fila:500,plant:1,leitos:0,total:16}");
  assert.equal(run(c, 'demand("upa").press'), 100);
});

test('demanda: limites dos níveis (49 baixa, 50 moderada, 89 alta, 90 crítica)', () => {
  const c = loadSite();
  const lvl = (score) => run(c, `LEVELS.filter(function(l){return ${score}<l.max;})[0].id`);
  assert.equal(lvl(49), 'baixa');
  assert.equal(lvl(50), 'moderada');
  assert.equal(lvl(74), 'moderada');
  assert.equal(lvl(75), 'alta');
  assert.equal(lvl(89), 'alta');
  assert.equal(lvl(90), 'critica');
});

test('dados: toda unidade tem coordenadas e todo médico aponta para uma unidade existente', () => {
  const c = loadSite();
  assert.equal(run(c, 'HOSPITALS.every(function(h){return typeof h.lat==="number"&&typeof h.lng==="number";})'), true);
  assert.equal(run(c, 'DOCS.every(function(d){return !!hosp(d.h);})'), true);
});

test('agenda: médico ausente não tem horários no período da ausência', () => {
  const c = loadSite();
  // Dr. Rafael Teixeira (rt) está ausente de hoje até hoje+6
  assert.equal(run(c, 'slotsFor(DOCS.filter(function(d){return d.id==="rt";})[0], today()).length'), 0);
});

test('agenda: datas e horas', () => {
  const c = loadSite();
  assert.equal(run(c, 'toMin("08:30")'), 510);
  assert.equal(run(c, 'fromMin(510)'), '08:30');
  assert.equal(run(c, 'key(fromKey("2026-10-23"))'), '2026-10-23');
  assert.equal(run(c, 'fmtDias([1,2,3,4,5])'), 'seg a sex');
});

test('segurança: esc() neutraliza HTML', () => {
  const c = loadSite();
  assert.equal(run(c, 'esc("<img src=x onerror=alert(1)>")'), '&lt;img src=x onerror=alert(1)&gt;');
});
