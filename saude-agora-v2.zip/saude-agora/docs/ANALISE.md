# Análise do código e melhorias (v1 → v2)

## O que já estava bom
- Separação em módulos por responsabilidade e CSS por seção.
- Acessibilidade acima da média: modo acolhedor, tamanho de letra, `aria-live`, foco visível.
- Escape de HTML (`esc`) nos dados dinâmicos e regra de negócio isolada (`demand`, `schedule`).
- Avisos claros de que os dados são fictícios.

## Problemas encontrados e correções

| # | Problema (v1) | Impacto | Correção (v2) |
|---|---|---|---|
| 1 | Busca usava `PlacesService.nearbySearch` (Places API legacy) | Não pode mais ser ativada em projetos novos (desde out/2026): o mapa falharia com chave nova | Migrado para `Place.searchNearby` (Places API New) |
| 2 | Mapa só funcionava com chave paga | Quem abre o repositório não via mapa nenhum | Padrão sem chave (Leaflet + OpenStreetMap); Google opcional, com fallback automático |
| 3 | Mapa não usava os dados do próprio site | Duas "metades" desconectadas | Marcadores coloridos pela demanda de cada unidade; ordenar por "mais perto" ou "menos cheia"; atualiza ao mudar o painel |
| 4 | Selecionar "nenhum" na rota (`Number('')` → 0) calculava rota até o 1º hospital | Bug lógico | Valor vazio é tratado explicitamente |
| 5 | Marcadores se acumulavam a cada busca e o InfoWindow criava marcador novo a cada clique | Vazamento e mapa poluído | Camadas limpas a cada redesenho |
| 6 | `google.maps.Marker` e `rating.slice(3)` (gambiarra de string) | API depreciada, código frágil | `AdvancedMarkerElement`; montagem por DOM |
| 7 | Resultados montados com `innerHTML` + dados externos | Risco de XSS vindo da API | `textContent`/`createElement` em todo o mapa |
| 8 | Se a localização fosse negada, nada acontecia | UX ruim | Usa o centro de Belém e avisa |
| 9 | Comentários de ambiente de preview no CSS, sem `<meta description>`, favicon ou "pular conteúdo" | Qualidade/acessibilidade | Corrigidos |
| 10 | Sem testes, README, licença ou CI | Difícil de avaliar/publicar | `npm test` (7 testes), README, MIT, workflow de deploy |

## Fora do escopo desta versão (próximos passos)
- Backend (Node + Express + banco) para persistir consultas e compartilhar a demanda entre usuários, com autenticação no painel da equipe.
- Migrar os scripts globais para ES Modules e `const/let` (hoje misturam `var` e ES6).
- Dados reais de hospitais de Belém via fonte oficial, com consentimento/convênio.
- Testes de interface (Playwright) e auditoria de acessibilidade (axe/Lighthouse).
